from botcity.core import DesktopBot
from botcity.maestro import *

BotMaestroSDK.RAISE_NOT_CONNECTED = False

maestro = BotMaestroSDK.from_sys_args()
execution = maestro.get_execution()


class Bot(DesktopBot) :


    def find_button(self, label) :
        try :
            if not self.find(label,  matching=0.97, waiting_time=10000) :
                raise Exception("Element not found")
        except Exception as error :
            print("Error")
            filepath = self.save_screenshot(r"C:\Users\Usuário\Desktop\printserros\screenshot.png")
            maestro.error(task_id=execution.task_id,
                          exception=error,
                          screenshot=filepath)
            maestro.alert(task_id=execution.task_id,
                          title="Title",
                          message="Erro ao executar o Bot",
                          alert_type=AlertType.ERROR)




    def action(self,execution=None) :
        
        self.execute(r"C:\Teorema\bin\contabil")
        self.wait(6000)
        self.tab()

        self.type_keys_with_interval(100,"teorema")
        self.wait(1000)
        self.tab()
        self.tab()
    
        self.wait(1000)
        self.type_keys_with_interval(100,"1811")
        self.wait(1000)
        self.enter()
        self.wait(1000)
        self.enter()
        self.wait(1000)
        self.enter()
        
        if not self.find( "cont_cadastros_1", matching=0.97, waiting_time=10000):
            not_found("cont_cadastros_1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_empresas_rel_para", matching=0.97, waiting_time=10000):
            not_found("cont_empresas_rel_para")
        self.click_relative(57, -14)
        
        if not self.find( "cont_empresas_empresas", matching=0.97, waiting_time=10000):
            not_found("cont_empresas_empresas")
        self.click()
        if not self.find( "cont_localizar_empresas_cadastro", matching=0.97, waiting_time=10000):
            not_found("cont_localizar_empresas_cadastro")
        self.click()
        if not self.find( "cont_incluir_cadastro_empresa", matching=0.97, waiting_time=10000):
            not_found("cont_incluir_cadastro_empresa")
        self.click()
        self.wait(1000)
        if not self.find( "cont_cadastro_empresa_nao", matching=0.97, waiting_time=10000):
            not_found("cont_cadastro_empresa_nao")
        self.click()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        self.type_down()
        self.type_down()
        self.type_down()
        self.tab()
        self.type_keys_with_interval(100,"11517192935")
        self.tab()
        self.type_keys_with_interval(100,"12312312333")
        self.wait(1000)
        self.tab()
        self.type_down()
        self.type_up()
        self.tab()
        self.tab()
        self.type_keys_with_interval(1,"qa12!@")
        self.tab()
        x = 0
        while x < 5:
            self.type_down()
            x += 1 
        x = 0
        self.tab()
        while x < 8:
            self.type_down()
            x += 1
        self.tab()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        self.type_keys_with_interval(100,"123")
        if not self.find( "cont_municipio_buscar", matching=0.97, waiting_time=10000):
            not_found("cont_municipio_buscar")
        self.click_relative(56, 27)
        if not self.find( "cont_localizar_municipios", matching=0.97, waiting_time=10000):
            not_found("cont_localizar_municipios")
        self.click()
        if not self.find( "cont_selecionar_municipios", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_municipios")
        self.click()
        self.tab()
        self.tab()
        self.type_keys_with_interval(100,"85050440")
        self.tab()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        self.type_keys_with_interval(100,"123123123")
        self.tab()
        self.type_keys_with_interval(100,"123123123")
        self.tab()
        self.type_keys_with_interval(100,"qa12@teorema.com")
        self.tab()
        self.type_keys_with_interval(100,"www.google.com") 
        self.tab()
        self.type_keys_with_interval(100,"qa12!@")      
        if not self.find( "cont_funcao_responsavel_buscar", matching=0.97, waiting_time=10000):
            not_found("cont_funcao_responsavel_buscar")
        self.click_relative(50, 26)
        if not self.find( "cont_localizar_municipios", matching=0.97, waiting_time=10000):
            not_found("cont_localizar_municipios")
        self.click()
        if not self.find( "cont_selecionar_municipios", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_municipios")
        self.click()
        self.tab()
        self.tab()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        self.type_keys_with_interval(100,"11517192935")
        self.tab()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        self.type_keys_with_interval(100,"11517192935")
        self.tab()
        self.type_keys_with_interval(100,"123123123")
        self.tab()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        self.type_keys_with_interval(100,"www.google.com")
        self.tab()
        self.type_keys_with_interval(100,"123123123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        if not self.find( "cont_2_informacoes_de_recursos", matching=0.97, waiting_time=10000):
            not_found("cont_2_informacoes_de_recursos")
        self.click()
        x = 0
        while x < 13:
            self.type_keys_with_interval(100,"123")
            self.tab()
            x += 1
          
        x = 0 
        while x < 6:
            self.type_down()
            x += 1
        self.tab()
        
        x = 0 
        while x < 6:
            self.type_down()
            x += 1
            
        self.tab()
        x = 0 
        while x < 6:
            self.type_down()
            x += 1
        self.tab()
        self.type_keys_with_interval(100,"12312312333")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        x = 0 
        while x < 6:
            self.type_down()
            x += 1
        x = 0 
        
        while x < 6:
            self.type_up()
            x += 1
        self.tab()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        if not self.find( "Cont_6_RaisDSRGPS", matching=0.97, waiting_time=10000):
            not_found("Cont_6_RaisDSRGPS")
        self.click()
        
        self.wait(1000)
        if not self.find( "Cont_gerar_RAIS", matching=0.97, waiting_time=10000):
            not_found("Cont_gerar_RAIS")
        self.click()
        
        self.space()
        self.space()
        self.tab()
        self.space()
        self.space()
        self.tab()
        self.space()
        self.space()
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_down()
        self.type_down()
        self.type_down()
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")

        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.space()
        self.space()
        self.space()
        self.tab()
        self.space()
        self.space()
        self.space()
        self.tab()
        self.space()
        self.space()
        self.space()
        self.tab()
        self.space()
        self.space()
        self.space()
        self.tab()
        self.space()
        self.space()
        self.space()
        self.tab()
        self.space()
        self.space()
        self.space()
        self.tab()
        self.space()
        self.space()
        self.space()
        self.tab()
        self.space()
        self.space()
        self.space()
        self.tab()
        
        x = 0
        while x < 6:
            self.type_down()
            x += 1
        
        self.tab()
        self.type_down()
        self.type_down()
 
        self.tab()
        self.space()
        self.space()
        self.tab()
        self.space()
        self.space()
        self.tab()
        self.space()
        self.space()
        self.tab()
        self.type_down()
        self.type_down()
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_down()
        self.type_down()
        self.tab()
        self.space()
        self.space()
        self.tab()
        self.space()
        self.space()
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_down()
        self.type_down()
        self.tab()
        x = 0
        while x <12:
            self.type_keys_with_interval(100,"123")
            self.tab()
            x += 1
        self.space()
        self.space()
        self.tab()
        self.type_keys_with_interval(100,"123")
        if not self.find( "cont_7_mensagens_observacoes", matching=0.97, waiting_time=10000):
            not_found("cont_7_mensagens_observacoes")
        self.click()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        if not self.find( "cont_3_informacoes_fiscais", matching=0.97, waiting_time=10000):
            not_found("cont_3_informacoes_fiscais")
        self.click()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        
        x = 0
        while x < 7:
            self.type_down()
            x += 1
        self.tab()
        x = 0
        while x < 12:
            self.type_down()
            x += 1
            
        self.tab()
        
        x = 0
        while x < 4:
            self.type_down()
            x += 1
        self.tab()
        x = 0
        while x < 6:
            self.type_down()
            x += 1
            
            
        self.tab()
        self.space()
        self.space()
        self.space()
        self.tab()
        self.space()
        self.space()
        self.space()
        
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        while x < 6:
            self.type_down()
            x += 1
        self.tab()
        while x < 7:
            self.type_down()
            x += 1
        self.tab()
        while x < 20:
            self.type_down()
            x += 1
        x = 0
        while x <6:
            self.space()
            self.wait(1000)
            self.space()
            self.tab()
            x += 1
        self.tab()
        self.type_down()
        self.type_down()
        if not self.find( "cont_4_agrupamentos", matching=0.97, waiting_time=10000):
            not_found("cont_4_agrupamentos")
        self.click()
        self.wait(1000)
        if not self.find( "cont_grupo_de_empresas_buscar", matching=0.97, waiting_time=10000):
            not_found("cont_grupo_de_empresas_buscar")
        self.click_relative(68, 28)
        self.wait(1000)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_selecionar_1", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_usa_clientes_forn_buscar", matching=0.97, waiting_time=10000):
            not_found("cont_usa_clientes_forn_buscar")
        self.click_relative(69, 27)
        self.wait(1000)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_selecionar_1", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_usa_plano_de_custos_buscar", matching=0.97, waiting_time=10000):
            not_found("cont_usa_plano_de_custos_buscar")
        self.click_relative(71, 25)
        self.wait(1000)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_selecionar_1", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_tabela_de_precos", matching=0.97, waiting_time=10000):
            not_found("cont_tabela_de_precos")
        self.click_relative(66, 27)
        self.wait(1000)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_selecionar_1", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_1")
        self.click()
        self.wait(1000)
        self.backspace()
        if not self.find( "cont_usa_contratos_da_empresa", matching=0.97, waiting_time=10000):
            not_found("cont_usa_contratos_da_empresa")
        self.click_relative(69, 31)
        self.wait(1000)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_selecionar_1", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_1")
        self.click()
        if not self.find( "cont_usa_planos_de_contas_da_empresa", matching=0.97, waiting_time=10000):
            not_found("cont_usa_planos_de_contas_da_empresa")
        self.click_relative(68, 30)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        if not self.find( "cont_selecionar_1", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_1")
        self.click()
        if not self.find( "cont_usa_itens_da_empresa", matching=0.97, waiting_time=10000):
            not_found("cont_usa_itens_da_empresa")
        self.click_relative(67, 26)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        if not self.find( "cont_selecionar_1", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_1")
        self.click()
        if not self.find( "cont_usa_vendedores_da_empresa", matching=0.97, waiting_time=10000):
            not_found("cont_usa_vendedores_da_empresa")
        self.click_relative(68, 27)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        if not self.find( "cont_selecionar_1", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_1")
        self.click()
        if not self.find( "cont_tabela_de_precos_servico_busc", matching=0.97, waiting_time=10000):
            not_found("cont_tabela_de_precos_servico_busc")
        self.click_relative(66, 23)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        if not self.find( "cont_selecionar_1", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_1")
        self.click()
        self.wait(1000)
        self.backspace()
        self.backspace()
        self.backspace()
        self.backspace()
        if not self.find( "cont_contabilista_busc", matching=0.97, waiting_time=10000):
            not_found("cont_contabilista_busc")
        self.click_relative(68, 24)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_selecionar_ccliente", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_ccliente")
        self.click()
        
        self.wait(1000)

        #
        if not self.find( "cont_usa_historico_da_empre_busc", matching=0.97, waiting_time=10000):
            not_found("cont_usa_historico_da_empre_busc")
        self.click_relative(71, 29)
        
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        if not self.find( "cont_selecionar_1", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_1")
        self.click()
        if not self.find( "cont_usa_precos_da_empresa_busc", matching=0.97, waiting_time=10000):
            not_found("cont_usa_precos_da_empresa_busc")
        self.click_relative(67, 29)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        if not self.find( "cont_selecionar_1", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_1")
        self.click()
        if not self.find( "cont_usa_situacao_da_empresa_busc", matching=0.97, waiting_time=10000):
            not_found("cont_usa_situacao_da_empresa_busc")
        self.click_relative(68, 31)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        if not self.find( "cont_selecionar_1", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_1")
        self.click()
        if not self.find( "cont_usa_veiculos_da_empresa_busc", matching=0.97, waiting_time=10000):
            not_found("cont_usa_veiculos_da_empresa_busc")
        self.click_relative(69, 28)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        if not self.find( "cont_selecionar_1", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_1")
        self.click()
        #MOUSE JA PAROU EM CIMA DO SALVAR
        #if not self.find( "cont_botao_de_salvar_cadastro", matching=0.97, waiting_time=10000):
            #not_found("cont_botao_de_salvar_cadastro")
        self.wait(1000)
        self.click()
        
        
        if not self.find( "cont_contas_de_cliente_1", matching=0.97, waiting_time=10000):
            not_found("cont_contas_de_cliente_1")
        self.click_relative(123, 26)
        
        if not self.find( "cont_lupta_localizar_f12", matching=0.97, waiting_time=10000):
            not_found("cont_lupta_localizar_f12")
        self.click()
        #mouse esta em cima
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_selecionar_outro_2", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_outro_2")
        self.click()
        
        
        
        if not self.find( "cont_contas_de_fornecedores_2", matching=0.97, waiting_time=10000):
            not_found("cont_contas_de_fornecedores_2")
        self.click_relative(125, 26)
        
        if not self.find( "cont_lupta_localizar_f12", matching=0.97, waiting_time=10000):
            not_found("cont_lupta_localizar_f12")
        self.click()
        
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        if not self.find( "cont_selecionar_outro_2", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_outro_2")
        self.click()
        
        if not self.find( "cont_codigo_contabil_clientes", matching=0.97, waiting_time=10000):
            not_found("cont_codigo_contabil_clientes")
        self.click_relative(127, 26)
        
        if not self.find( "cont_lupta_localizar_f12", matching=0.97, waiting_time=10000):
            not_found("cont_lupta_localizar_f12")
        self.click()
        
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        if not self.find( "cont_selecionar_outro_2", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_outro_2")
        self.click()
        
        if not self.find( "cont_codigo_contabil_fornecedor", matching=0.97, waiting_time=10000):
            not_found("cont_codigo_contabil_fornecedor")
        self.click_relative(126, 27)
        
        if not self.find( "cont_lupta_localizar_f12", matching=0.97, waiting_time=10000):
            not_found("cont_lupta_localizar_f12")
        self.click()
        
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        if not self.find( "cont_selecionar_outro_2", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_outro_2")
        self.click()
        
        if not self.find( "cont_conta_contabil_1", matching=0.97, waiting_time=10000):
            not_found("cont_conta_contabil_1")
        self.click_relative(125, 27)
        
        if not self.find( "cont_lupta_localizar_f12", matching=0.97, waiting_time=10000):
            not_found("cont_lupta_localizar_f12")
        self.click()
        
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        if not self.find( "cont_selecionar_outro_2", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_outro_2")
        self.click()
        
        if not self.find( "cont_conta_contabil_2", matching=0.97, waiting_time=10000):
            not_found("cont_conta_contabil_2")
        self.click_relative(126, 28)
        
        if not self.find( "cont_lupta_localizar_f12", matching=0.97, waiting_time=10000):
            not_found("cont_lupta_localizar_f12")
        self.click()
        
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        if not self.find( "cont_selecionar_outro_2", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_outro_2")
        self.click()
        
        if not self.find( "cont_conta_contabil_3", matching=0.97, waiting_time=10000):
            not_found("cont_conta_contabil_3")
        self.click_relative(127, 27)
        
        if not self.find( "cont_lupta_localizar_f12", matching=0.97, waiting_time=10000):
            not_found("cont_lupta_localizar_f12")
        self.click()
        
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        if not self.find( "cont_selecionar_outro_2", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_outro_2")
        self.click()
        
        if not self.find( "cont_conta_contabil_4", matching=0.97, waiting_time=10000):
            not_found("cont_conta_contabil_4")
        self.click_relative(91, 28)
        
        if not self.find( "cont_lupta_localizar_f12", matching=0.97, waiting_time=10000):
            not_found("cont_lupta_localizar_f12")
        self.click()
        
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        if not self.find( "cont_selecionar_outro_2", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_outro_2")
        self.click()
        
        if not self.find( "cont_conta_contabil_5", matching=0.97, waiting_time=10000):
            not_found("cont_conta_contabil_5")
        self.click_relative(126, 27)
        
        if not self.find( "cont_lupta_localizar_f12", matching=0.97, waiting_time=10000):
            not_found("cont_lupta_localizar_f12")
        self.click()
        
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        if not self.find( "cont_selecionar_outro_2", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_outro_2")
        self.click()
        self.wait(1000)
        if not self.find( "cont_conta_contabil_6", matching=0.97, waiting_time=10000):
            not_found("cont_conta_contabil_6")
        self.click_relative(127, 28)
        self.wait(1000)
        if not self.find( "cont_lupta_localizar_f12", matching=0.97, waiting_time=10000):
            not_found("cont_lupta_localizar_f12")
        self.click()
        self.wait(1000)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_selecionar_outro_2", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_outro_2")
        self.click()
        self.wait(1000)
        if not self.find( "cont_conta_contabil_7", matching=0.97, waiting_time=10000):
            not_found("cont_conta_contabil_7")
        self.click_relative(125, 27)
        self.wait(1000)
        if not self.find( "cont_lupta_localizar_f12", matching=0.97, waiting_time=10000):
            not_found("cont_lupta_localizar_f12")
        self.click()
        self.wait(1000)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_selecionar_outro_2", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_outro_2")
        self.click()
        self.wait(1000)
        if not self.find( "cont_conta_contabil_8", matching=0.97, waiting_time=10000):
            not_found("cont_conta_contabil_8")
        self.click_relative(124, 25)
        self.wait(1000)
        if not self.find( "cont_lupta_localizar_f12", matching=0.97, waiting_time=10000):
            not_found("cont_lupta_localizar_f12")
        self.click()
        self.wait(1000)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_selecionar_outro_2", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_outro_2")
        self.click()
        self.wait(1000)
        if not self.find( "cont_conta_contabil_9", matching=0.97, waiting_time=10000):
            not_found("cont_conta_contabil_9")
        self.click_relative(126, 25)
        self.wait(1000)
        if not self.find( "cont_lupta_localizar_f12", matching=0.97, waiting_time=10000):
            not_found("cont_lupta_localizar_f12")
        self.click()
        self.wait(1000)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_selecionar_outro_2", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_outro_2")
        self.click()
        self.wait(1000)
        if not self.find( "cont_conta_contabil_10", matching=0.97, waiting_time=10000):
            not_found("cont_conta_contabil_10")
        self.click_relative(126, 26)
        self.wait(1000)
        if not self.find( "cont_lupta_localizar_f12", matching=0.97, waiting_time=10000):
            not_found("cont_lupta_localizar_f12")
        self.click()
        self.wait(1000)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_selecionar_outro_2", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_outro_2")
        self.click()
        self.wait(1000)
        if not self.find( "cont_conta_contabil_11", matching=0.97, waiting_time=10000):
            not_found("cont_conta_contabil_11")
        self.click_relative(126, 26)
        self.wait(1000)
        if not self.find( "cont_lupta_localizar_f12", matching=0.97, waiting_time=10000):
            not_found("cont_lupta_localizar_f12")
        self.click()
        self.wait(1000)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_selecionar_outro_2", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_outro_2")
        self.click()
        self.wait(1000)
        if not self.find( "cont_conta_contabil_12", matching=0.97, waiting_time=10000):
            not_found("cont_conta_contabil_12")
        self.click_relative(90, 29)
        self.wait(1000)
        if not self.find( "cont_lupta_localizar_f12", matching=0.97, waiting_time=10000):
            not_found("cont_lupta_localizar_f12")
        self.click()
        self.wait(1000)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_selecionar_outro_2", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_outro_2")
        self.click()
        self.wait(1000)
        if not self.find( "cont_conta_contabil_13", matching=0.97, waiting_time=10000):
            not_found("cont_conta_contabil_13")
        self.click_relative(93, 28)
        self.wait(1000)
        if not self.find( "cont_lupta_localizar_f12", matching=0.97, waiting_time=10000):
            not_found("cont_lupta_localizar_f12")
        self.click()
        self.wait(1000)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_selecionar_outro_2", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_outro_2")
        self.click()
        self.wait(1000)
        if not self.find( "cont_conta_contabil_14", matching=0.97, waiting_time=10000):
            not_found("cont_conta_contabil_14")
        self.click_relative(127, 29)
        self.wait(1000)
        if not self.find( "cont_lupta_localizar_f12", matching=0.97, waiting_time=10000):
            not_found("cont_lupta_localizar_f12")
        self.click()
        self.wait(1000)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_selecionar_outro_2", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_outro_2")
        self.click()
        self.wait(1000)
        self.tab()
        self.tab()
        if not self.find( "cont_5_relacionamentos_cad", matching=0.97, waiting_time=10000):
            not_found("cont_5_relacionamentos_cad")
        self.click()
        if not self.find( "cont_botao_salvar_cad_5", matching=0.97, waiting_time=10000):
            not_found("cont_botao_salvar_cad_5")
        self.click()
        if not self.find( "cont_incluir_A_inscricoes_estaduais", matching=0.97, waiting_time=10000):
            not_found("cont_incluir_A_inscricoes_estaduais")
        self.click()
        if not self.find( "cont_botao_buscar_estado_5", matching=0.97, waiting_time=10000):
            not_found("cont_botao_buscar_estado_5")
        self.click()
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_selecionar_5_A", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_5_A")
        self.click()
        self.wait(1000)
        self.tab()
        self.tab()
        self.type_keys_with_interval(100,"1")
        self.tab()
        self.enter()
        if not self.find( "cont_x_Cancelar_5_A", matching=0.97, waiting_time=10000):
            not_found("cont_x_Cancelar_5_A")
        self.click()
        self.wait(1000)
        self.enter()
        if not self.find( "cont_lixeira_A_inscricoes", matching=0.97, waiting_time=10000):
            not_found("cont_lixeira_A_inscricoes")
        self.click()
        self.enter()
        if not self.find( "cont_B_socios_cad", matching=0.97, waiting_time=10000):
            not_found("cont_B_socios_cad")
        self.click()
        if not self.find( "cont_incluir_A_inscricoes_estaduais", matching=0.97, waiting_time=10000):
            not_found("cont_incluir_A_inscricoes_estaduais")
        self.click()

        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"11517192935")
        self.tab()
        self.type_keys_with_interval(100,"12312312333")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        x = 0
        while x < 8:
            self.type_down()
            self.wait(100)
            x += 1
        self.tab()
        self.type_keys_with_interval(100,"85050440")
        self.tab()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        self.type_keys_with_interval(100,"qa12!@")
        self.tab()
        self.type_keys_with_interval(100,"4291472548")
        self.tab()
        self.type_keys_with_interval(100,"teoremateste@gmail.com")
        self.tab()

        x = 0
        while x < 8:
            self.type_down()
            self.wait(100)
            x += 1

        self.tab()
        self.type_keys_with_interval(100,"12")
        self.tab()
        self.type_keys_with_interval(100,"1")
        self.tab()
        

        x = 0
        while x < 25:
            self.type_down()
            self.wait(100)
            x += 1

        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.type_keys_with_interval(100,"1")
        self.tab()
        self.type_keys_with_interval(100,"1")
        self.tab()
        self.type_keys_with_interval(100,"1")
        self.tab()
        self.type_keys_with_interval(100,"1")
        self.tab()
        self.space()
        self.space()
        self.tab()
        self.space()
        self.space()
        self.tab()
        self.space()
        self.space()
        self.tab()
        self.space()
        self.space()
        self.tab()
        self.wait(1000)
        if not self.find( "cont_b_funcao", matching=0.97, waiting_time=10000):
            not_found("cont_b_funcao")
        self.click_relative(331, 24)
        self.wait(1000)
        if not self.find( "cont_b_funcao_descricao", matching=0.97, waiting_time=10000):
            not_found("cont_b_funcao_descricao")
        self.click_relative(40, 25)
        self.wait(1000)
        if not self.find( "cont_b_banco", matching=0.97, waiting_time=10000):
            not_found("cont_b_banco")
        self.click_relative(326, 26)
        self.wait(1000)
        if not self.find( "cont_b_banco_descricao", matching=0.97, waiting_time=10000):
            not_found("cont_b_banco_descricao")
        self.click_relative(69, 20)
        self.wait(1000)
        self.tab()
        self.wait(1000)
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.wait(1000)
        self.type_keys_with_interval(100,"123")
        self.tab()
        self.wait(1000)
        self.type_keys_with_interval(100,"qa12!@")
        if not self.find( "cont_salvar_b_socio", matching=0.97, waiting_time=10000):
            not_found("cont_salvar_b_socio")
        self.click()
        if not self.find( "cont_cancelar_b_socio_cad", matching=0.97, waiting_time=10000):
            not_found("cont_cancelar_b_socio_cad")
        self.click()
        self.wait(1000)
        self.enter()
        self.wait(1000)
        if not self.find( "cont_lixeira_A_inscricoes", matching=0.97, waiting_time=10000):
            not_found("cont_lixeira_A_inscricoes")
        self.click()
        self.wait(1000)
        self.enter()
        if not self.find( "cont_c_documentos_cad", matching=0.97, waiting_time=10000):
            not_found("cont_c_documentos_cad")
        self.click()
        if not self.find( "cont_incluir_A_inscricoes_estaduais", matching=0.97, waiting_time=10000):
            not_found("cont_incluir_A_inscricoes_estaduais")
        self.click()
        self.wait(1000)
        self.tab()
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        if not self.find( "cont_livro_c_documentos", matching=0.97, waiting_time=10000):
            not_found("cont_livro_c_documentos")
        self.click()
        self.wait(1000)
        self.enter()
        self.wait(1000)
        if not self.find( "cont_arquivos_c_documentos", matching=0.97, waiting_time=10000):
            not_found("cont_arquivos_c_documentos")
        self.click()
        self.wait(1000)
        self.tab()
        self.tab()
        self.tab()
        self.wait(1000)
        self.enter()
        self.wait(1000)
        if not self.find( "cont_salvar_b_socio", matching=0.97, waiting_time=10000):
            not_found("cont_salvar_b_socio")
        self.click()
        self.wait(1000)
        if not self.find( "cont_cancelar_b_socio_cad", matching=0.97, waiting_time=10000):
            not_found("cont_cancelar_b_socio_cad")
        self.click()
        self.wait(1000)
        self.enter()
        self.wait(1000)

        if not self.find( "cont_lixeira_A_inscricoes", matching=0.97, waiting_time=10000):
            not_found("cont_lixeira_A_inscricoes")
        self.click()
        self.wait(1000)
        self.enter()
        if not self.find( "cont_d_pessoas_autorizadas", matching=0.97, waiting_time=10000):
            not_found("cont_d_pessoas_autorizadas")
        self.click()
        if not self.find( "cont_incluir_A_inscricoes_estaduais", matching=0.97, waiting_time=10000):
            not_found("cont_incluir_A_inscricoes_estaduais")
        self.click()
        if not self.find( "cont_botao_buscar_estado_5", matching=0.97, waiting_time=10000):
            not_found("cont_botao_buscar_estado_5")
        self.click()
        self.wait(1000)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_selecionar_contas_autorizadas", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_contas_autorizadas")
        self.click()
        if not self.find( "cont_salvar_b_socio", matching=0.97, waiting_time=10000):
            not_found("cont_salvar_b_socio")
        self.click()
        self.wait(1000)
        if not self.find( "cont_cancelar_b_socio_cad", matching=0.97, waiting_time=10000):
            not_found("cont_cancelar_b_socio_cad")
        self.click()
        self.wait(1000)
        self.enter()
        self.wait(1000)
        if not self.find( "cont_lixeira_A_inscricoes", matching=0.97, waiting_time=10000):
            not_found("cont_lixeira_A_inscricoes")
        self.click()
        self.wait(1000)
        self.enter()
        self.wait(1000)
        if not self.find( "cont_gnre_botao_cadastro", matching=0.97, waiting_time=10000):
            not_found("cont_gnre_botao_cadastro")
        self.click()
        self.wait(1000)
        self.type_down()
        if not self.find( "cont_numero_de_serie_pasta", matching=0.97, waiting_time=10000):
            not_found("cont_numero_de_serie_pasta")
        self.click_relative(437, 28)
        self.wait(1000)
        self.key_esc()
        self.wait(1000)
        self.tab()
        self.type_keys_with_interval(100,"123")
        self.tab()
        if not self.find( "cont_pastados_schemas", matching=0.97, waiting_time=10000):
            not_found("cont_pastados_schemas")
        self.click_relative(440, 27)
        self.wait(1000)
        self.key_esc()
        self.wait(1000)
        self.tab()
        if not self.find( "contpasta_de_arquivos_gerados", matching=0.97, waiting_time=10000):
            not_found("contpasta_de_arquivos_gerados")
        self.click_relative(437, 27)
        self.wait(1000)
        self.key_esc()
        self.tab()
        self.type_down()
        self.type_up()
        self.tab()
        self.type_down()
        self.type_down()
        self.type_up()
        self.type_up()
        self.wait(1000)
        if not self.find( "cont_botao_de_salvar_cadastro", matching=0.97, waiting_time=10000):
            not_found("cont_botao_de_salvar_cadastro")
        self.wait(1000)
        self.click()
        self.wait(1000)
        if not self.find( "cont_retornar_cadastro_empresa_", matching=0.97, waiting_time=10000):
            not_found("cont_retornar_cadastro_empresa_")
        self.click()
        self.wait(1000)
        if not self.find( "cont_loc_empresa_criada", matching=0.97, waiting_time=10000):
            not_found("cont_loc_empresa_criada")
        self.click()
        self.wait(1000)
        if not self.find( "cont_achar_qa12_empresa", matching=0.97, waiting_time=10000):
            not_found("cont_achar_qa12_empresa")
        self.double_click()
        self.wait(1000)
        if not self.find( "cont_excluir_empresa_criada", matching=0.97, waiting_time=10000):
            not_found("cont_excluir_empresa_criada")
        self.click()
        self.wait(1000)
        self.enter()
        self.wait(1000)
        if not self.find( "cont_retornar_cadastro_empresa_", matching=0.97, waiting_time=10000):
            not_found("cont_retornar_cadastro_empresa_")
        self.click()
        self.wait(1000)
        self.wait(1000)
        if not self.find( "cont_loc_empresa_criada", matching=0.97, waiting_time=10000):
            not_found("cont_loc_empresa_criada")
        self.click()
        self.wait(1000)
        self.wait(1000)
        if not self.find( "cont_retornar_cadastro_empresa_", matching=0.97, waiting_time=10000):
            not_found("cont_retornar_cadastro_empresa_")
        self.click()
        self.wait(1000)
        if not self.find( "cont_cadastros_1", matching=0.97, waiting_time=10000):
            not_found("cont_cadastros_1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_empresas_rel_para", matching=0.97, waiting_time=10000):
            not_found("cont_empresas_rel_para")
        self.click_relative(57, -14)
        if not self.find( "cont_grupo_de_empresas_cad", matching=0.97, waiting_time=10000):
            not_found("cont_grupo_de_empresas_cad")
        self.click()
        self.wait(1000)
        if not self.find( "cont_loc_empresa_criada", matching=0.97, waiting_time=10000):
            not_found("cont_loc_empresa_criada")
        self.click()
        self.wait(1000)
        if not self.find( "cont_incluir_cadastro_empresa", matching=0.97, waiting_time=10000):
            not_found("cont_incluir_cadastro_empresa")
        self.click()
        self.wait(1000)
        self.type_keys_with_interval(100,"qa12!@")
        self.wait(1000)
        self.wait(1000)
        if not self.find( "cont_botao_de_salvar_cadastro", matching=0.97, waiting_time=10000):
            not_found("cont_botao_de_salvar_cadastro")
        self.click()
        self.wait(1000)
        if not self.find( "cont_retornar_cadastro_empresa_", matching=0.97, waiting_time=10000):
            not_found("cont_retornar_cadastro_empresa_")
        self.click()
        self.wait(1000)
        if not self.find( "cont_rel_loc_empresa_cadastro", matching=0.97, waiting_time=10000):
            not_found("cont_rel_loc_empresa_cadastro")
        self.click_relative(-90, 11)
        if not self.find( "cont_achar_qa_12_empresa_cad", matching=0.97, waiting_time=10000):
            not_found("cont_achar_qa_12_empresa_cad")
        self.click()
        self.wait(1000)
        if not self.find( "cont_editar_cad_parametro_emp", matching=0.97, waiting_time=10000):
            not_found("cont_editar_cad_parametro_emp")
        self.click()
        self.wait(1000)
        if not self.find( "cont_excluir_empresa_criada", matching=0.97, waiting_time=10000):
            not_found("cont_excluir_empresa_criada")
        self.click()
        self.wait(1000)
        self.enter()
        self.wait(1000)
        if not self.find( "cont_retornar_cadastro_empresa_", matching=0.97, waiting_time=10000):
            not_found("cont_retornar_cadastro_empresa_")
        self.click()
        self.wait(1000)
        if not self.find( "cont_rel_loc_empresa_cadastro", matching=0.97, waiting_time=10000):
            not_found("cont_rel_loc_empresa_cadastro")
        self.click_relative(-90, 11)
        self.wait(1000)
        if not self.find( "cont_retornar_cadastro_empresa_", matching=0.97, waiting_time=10000):
            not_found("cont_retornar_cadastro_empresa_")
        self.click()
        self.wait(1000)
        if not self.find( "cont_cadastros_1", matching=0.97, waiting_time=10000):
            not_found("cont_cadastros_1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_parametros_cad", matching=0.97, waiting_time=10000):
            not_found("cont_parametros_cad")
        self.click()
        if not self.find( "cont_parametros_empresa_f9", matching=0.97, waiting_time=10000):
            not_found("cont_parametros_empresa_f9")
        self.click()
        self.wait(1000)
        if not self.find( "cont_loc_empresa_criada", matching=0.97, waiting_time=10000):
            not_found("cont_loc_empresa_criada")
        self.click()
        self.wait(1000)
        if not self.find( "cont_incluir_cadastro_empresa", matching=0.97, waiting_time=10000):
            not_found("cont_incluir_cadastro_empresa")
        self.click()
        self.wait(1000)
        if not self.find( "cont_nao_importar_dados", matching=0.97, waiting_time=10000):
            not_found("cont_nao_importar_dados")
        self.click()
        if not self.find( "cont_buscar_lupa_parametro_empresa", matching=0.97, waiting_time=10000):
            not_found("cont_buscar_lupa_parametro_empresa")
        self.click()
        self.wait(1000)
        if not self.find( "cont_localizar1", matching=0.97, waiting_time=10000):
            not_found("cont_localizar1")
        self.click()
        self.wait(1000)
        if not self.find( "cont_selecionar_parametros_cad", matching=0.97, waiting_time=10000):
            not_found("cont_selecionar_parametros_cad")
        self.click()
        self.wait(1000)
        if not self.find( "cont_cor_inicial_parametros", matching=0.97, waiting_time=10000):
            not_found("cont_cor_inicial_parametros")
        self.click_relative(162, 25)
        self.wait(1000)
        self.click()
        x = 0
        while x < 20:
            self.type_down()
            x += 1
        self.tab()
        x = 0
        while x < 20:
            self.type_down()
            x += 1
        self.tab()
        x = 0
        while x < 13:
            self.type_down()
            self.type_up()
            self.tab()
            x += 1 
        self.wait(1000)
        x = 0
        while x < 6:
            self.type_down()
            self.type_down()
            self.type_down()
            self.type_down()
            self.type_down()
            self.type_up()
            self.type_up()
            self.type_up()
            self.type_up()
            self.type_up()
            self.tab()
            x += 1
        self.type_up()
        self.tab()
        x = 0
        while x < 4:
            self.type_down()
            x += 1 
        x = 0
        while x < 4:
            self.type_up()
            x += 1
        self.tab()
        self.type_down()
        self.type_down()
        self.type_up()
        
        self.wait(3000)
        
        if not self.find( "cont_2_financeiros_parametros", matching=0.97, waiting_time=10000):
            not_found("cont_2_financeiros_parametros")
        self.click()
        x= 0
        while x < 15:
            self.type_down()
            self.type_down()
            self.type_down()
            self.type_down()
            self.type_down()
            self.type_up()
            self.type_up()
            self.type_up()
            self.type_up()
            self.type_up()
            self.tab()
            x += 1
        self.type_keys_with_interval(1,"1")
        self.tab()
        self.type_keys_with_interval(1,"1")
        self.tab()
        x = 0
        while x < 2:
            self.type_down()
            self.type_down()
            self.type_up()
            self.type_up()
            self.tab()
            x += 1
        self.type_keys_with_interval(1,"1")
        self.tab()
        self.type_down()
        self.type_up()
        self.tab()
        
        self.wait(3000)
        self.type_keys_with_interval(1,"1")
        self.tab()
        self.type_keys_with_interval(1,"1")
        self.tab()
        self.type_keys_with_interval(1,"1")
        self.tab()
        self.type_keys_with_interval(1,"1")
        self.tab()
        self.type_down()
        self.type_down()
        self.type_down()
        self.type_down()
        self.type_up()
        self.type_up()
        self.type_up()
        self.type_up()
        self.tab()
        self.type_down()
        self.type_up()
        self.tab()
        self.wait(1000)
        self.type_keys_with_interval(1,"1")
        self.tab()
        self.type_down()
        self.type_up()
        if not self.find( "cont_3_gestao_adm_parametros", matching=0.97, waiting_time=10000):
            not_found("cont_3_gestao_adm_parametros")
        self.click()
        
        

        



        
        
        
        

def not_found(label) :
    print(f"Element not found  {label}")
    
if __name__ == '__main__' :
    Bot.main()



























